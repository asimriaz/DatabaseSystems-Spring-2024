USE [master]

RESTORE DATABASE [EXAMS]
FROM DISK = '/usr/src/app/EXAMS.bak' 
WITH 
	 MOVE 'EXAMS' TO '/var/opt/mssql/data/EXAMS.mdf',
	 MOVE 'EXAMS_Log' TO '/var/opt/mssql/data/EXAMS_Log.ldf'